'''
Created on 2011 4 14

@author: cihancimen
'''

class AbstractCommand(object):
    '''
    classdocs
    '''


    def __init__(self, orig):
        '''
        Constructor
        '''
        self.orig = orig