PYTHONPATH should contain root directory or main class needs to be moved to root directory

Ismet Ozgur Colpankan    1560671
Cihan Cimen		 1560689


Run Main.py at src/python with two arguments <gamemode> <host> <port>
gamemode:
	1= CommandLine
	2= Socket
Run ClientMain.py at src/python/mains for socket client

All Commands
List commands
List my
List unoccupied
List cards
List neighbours
List all
List mission

Place <Territory> <Army Number>
Place <Territory>

Move <From Territory> <To Territory> <Army Number>

Attack <From Territory> <To Territory> <Dice Number>

Trade <first card number> <second card number> <third card number>